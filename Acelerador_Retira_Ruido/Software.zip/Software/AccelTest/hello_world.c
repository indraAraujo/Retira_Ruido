/*
 * "Hello World" example.
 *
 * This example prints 'Hello from Nios II' to the STDOUT stream. It runs on
 * the Nios II 'standard', 'full_featured', 'fast', and 'low_cost' example
 * designs. It runs with or without the MicroC/OS-II RTOS and requires a STDOUT
 * device in your system's hardware.
 * The memory footprint of this hosted application is ~69 kbytes by default
 * using the standard reference design.
 *
 * For a reduced footprint version of this template, and an explanation of how
 * to reduce the memory footprint for a given application, see the
 * "small_hello_world" template.
 *
 */

#include <stdio.h>
#include <time.h>
#include "system.h"

/*
 #define leds (char*) 0x210a0
 #define buttons (volatile char*) 0x21090
 #define reset (char*) 0x21040
 #define x (int*) 0x21070
 #define go (char*) 0x21080
 #define sqrtx (volatile int*) 0x21050
 #define dadoprt (volatile char*) 0x21060
 */

#define leds (char*) LEDS_BASE
#define buttons (volatile char*) BUTTONS_BASE
#define reset (char*) RESETPROC_BASE
#define x (int*) X_BASE
#define go (char*) GO_BASE
#define sqrtx (volatile int*) SQRTX_BASE
#define dadoprt (volatile char*) DADOPRT_BASE

int main() {

	*reset = 0;
	*reset = 1;
	*reset = 0;
	*x = 1492;
	*go = 1;
	while (!dadoprt);
	int resp = 0;
	resp = (int) *sqrtx;
	printf("O resultado de SQRT(x) eh: %d", resp);
	return 0;
}
